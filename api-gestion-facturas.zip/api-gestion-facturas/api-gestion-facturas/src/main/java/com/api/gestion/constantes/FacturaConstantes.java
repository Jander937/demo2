package com.api.gestion.constantes;

public class FacturaConstantes {

    public static final String SOMETHING_WENT_WRONG = "Algo salio mal";

    public static final String INVALID_DATA = "Datos invalidos";

}
